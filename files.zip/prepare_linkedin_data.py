"""
Mini Project - Data Collection
Topic: Is AI changing entry-level jobs? What do employers want from graduates?

Source (Kaggle): LinkedIn Job Postings (2023 - 2024) by Arsh Koneru
  https://www.kaggle.com/datasets/arshkon/linkedin-job-postings

What this script does:
  1. Reads the Kaggle files (postings, skills, industries, companies)
  2. Joins them into ONE table: one row per job posting
  3. Converts LinkedIn's timestamps (milliseconds) into normal dates
  4. Adds a few text flags from the job description
     (mentions AI?, years of experience asked for, description length)
  5. Drops the long description text so the file is small enough to share
  6. Saves: linkedin_jobs_2023_2024.csv

Folder layout before running (just unzip the Kaggle download into "data"):
  mini_project/
      prepare_linkedin_data.py
      data/
          postings.csv
          jobs/job_skills.csv, jobs/job_industries.csv, ...
          mappings/skills.csv, mappings/industries.csv
          companies/companies.csv, companies/employee_counts.csv, ...

How to run:
  python -m pip install pandas
  python prepare_linkedin_data.py
"""

import re
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
DATA_DIR = HERE / "data"

POSTING_COLS = [
    "job_id", "company_id", "company_name", "title", "location",
    "formatted_experience_level", "formatted_work_type", "remote_allowed",
    "min_salary", "med_salary", "max_salary", "pay_period", "currency",
    "compensation_type", "normalized_salary",
    "views", "applies", "application_type", "sponsored",
    "original_listed_time", "listed_time", "expiry", "closed_time",
]
TIME_COLS = ["original_listed_time", "listed_time", "expiry", "closed_time"]

# AI keywords: acronyms must be upper-case (so "ai"/"ml" inside normal text don't count)
AI_ACRONYMS = r"\b(?:AI|ML|LLMs?|NLP|GenAI)\b|ChatGPT|\bGPT-?\d"
AI_PHRASES = (r"artificial intelligence|machine learning|generative ai|deep learning|"
              r"large language model|prompt engineering|neural network")

# Years of experience: a number followed by "years" and then "experience" within a few words,
# e.g. "3+ years of experience", "2-4 years of relevant work experience"
YEARS_PATTERN = (r"(\d{1,2})\s*\+?\s*(?:-|to|–)?\s*(?:\d{1,2})?\s*\+?\s*(?:years?|yrs?)"
                 r"(?:\s+(?:of|in|with|minimum|min\.?|related|relevant|professional|progressive|"
                 r"working|work|hands-on|industry|prior|previous|direct|proven|recent)){0,4}"
                 r"\s+experience")


def find(name: str) -> Path | None:
    """Find a file by name anywhere inside the data folder."""
    hits = sorted(DATA_DIR.rglob(name))
    return hits[0] if hits else None


def read(name: str, **kw) -> pd.DataFrame | None:
    path = find(name)
    if path is None:
        print(f"  ! {name} not found - skipped")
        return None
    df = pd.read_csv(path, low_memory=False, **kw)
    print(f"  read {path.relative_to(DATA_DIR)}  ({len(df):,} rows)")
    return df


def main() -> None:
    if not DATA_DIR.exists():
        raise SystemExit(f"Folder not found: {DATA_DIR}\nUnzip the Kaggle download into it.")

    print("Reading Kaggle files ...")
    posts = read("postings.csv")
    if posts is None:
        raise SystemExit("postings.csv is required. Check that you unzipped the Kaggle file into 'data'.")

    # ---- 1. Text flags from the description, then drop the long text ----
    desc = posts.get("description", pd.Series("", index=posts.index)).fillna("").astype(str)
    skills_txt = posts.get("skills_desc", pd.Series("", index=posts.index)).fillna("").astype(str)
    full_text = desc + " " + skills_txt
    posts["mentions_ai"] = (full_text.str.contains(AI_ACRONYMS, case=True, regex=True)
                            | full_text.str.contains(AI_PHRASES, case=False, regex=True)).astype(int)
    years = full_text.str.extract(YEARS_PATTERN, flags=re.IGNORECASE, expand=False)
    posts["years_experience_asked"] = pd.to_numeric(years, errors="coerce")
    posts.loc[posts["years_experience_asked"] > 20, "years_experience_asked"] = pd.NA  # implausible
    posts["description_length"] = desc.str.len()

    keep = [c for c in POSTING_COLS if c in posts.columns]
    keep += ["mentions_ai", "years_experience_asked", "description_length"]
    jobs = posts[keep].copy()

    # ---- 2. Timestamps: LinkedIn stores milliseconds since 1970 ----
    for c in TIME_COLS:
        if c in jobs.columns:
            jobs[c] = pd.to_datetime(pd.to_numeric(jobs[c], errors="coerce"), unit="ms", errors="coerce")
    if "original_listed_time" in jobs.columns:
        jobs["listed_date"] = jobs["original_listed_time"].dt.date

    # ---- 3. Skills: one row per job -> "Skill A; Skill B" ----
    js, sk = read("job_skills.csv"), read("skills.csv")
    if js is not None:
        if sk is not None:
            js = js.merge(sk, on="skill_abr", how="left")
            js["skill_name"] = js["skill_name"].fillna(js["skill_abr"])
        else:
            js["skill_name"] = js["skill_abr"]
        jobs = jobs.merge(js.groupby("job_id")["skill_name"].agg("; ".join).rename("skills"),
                          on="job_id", how="left")

    # ---- 4. Industries ----
    ji, ind = read("job_industries.csv"), read("industries.csv")
    if ji is not None:
        if ind is not None:
            ji = ji.merge(ind, on="industry_id", how="left")
            ji["industry_name"] = ji["industry_name"].fillna(ji["industry_id"].astype(str))
        else:
            ji["industry_name"] = ji["industry_id"].astype(str)
        jobs = jobs.merge(ji.groupby("job_id")["industry_name"]
                          .agg(lambda s: "; ".join(s.astype(str))).rename("industries"),
                          on="job_id", how="left")

    # ---- 5. Company details ----
    comp = read("companies.csv")
    if comp is not None and "company_id" in jobs.columns:
        cols = [c for c in ["company_id", "company_size", "state", "country", "city"] if c in comp.columns]
        comp = comp[cols].drop_duplicates("company_id").rename(
            columns={"state": "company_state", "country": "company_country", "city": "company_city"})
        jobs = jobs.merge(comp, on="company_id", how="left")

    emp = read("employee_counts.csv")
    if emp is not None and "company_id" in jobs.columns:
        emp = emp.sort_values(emp.columns[-1]).drop_duplicates("company_id", keep="last")
        cols = [c for c in ["company_id", "employee_count", "follower_count"] if c in emp.columns]
        jobs = jobs.merge(emp[cols], on="company_id", how="left")

    # ---- 6. Save ----
    out = HERE / "linkedin_jobs_2023_2024.csv"
    jobs.to_csv(out, index=False)
    size_mb = out.stat().st_size / 1e6
    print(f"\nSaved {out}")
    print(f"{len(jobs):,} job postings x {jobs.shape[1]} columns  ({size_mb:.1f} MB)")

    if size_mb > 25:   # claude.ai uploads are limited to about 30 MB
        zip_out = HERE / "linkedin_jobs_2023_2024.zip"
        jobs.to_csv(zip_out, index=False,
                    compression={"method": "zip", "archive_name": "linkedin_jobs_2023_2024.csv"})
        print(f"Also saved a zipped copy for uploading: {zip_out} "
              f"({zip_out.stat().st_size / 1e6:.1f} MB)")

    if "formatted_experience_level" in jobs.columns:
        print("\nPostings by experience level:")
        print(jobs["formatted_experience_level"].value_counts(dropna=False).to_string())
    if "listed_date" in jobs.columns:
        print(f"\nListing dates: {jobs['listed_date'].min()} -> {jobs['listed_date'].max()}")


if __name__ == "__main__":
    main()
